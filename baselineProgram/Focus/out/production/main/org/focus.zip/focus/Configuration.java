package org.focus;

/**
 * TODO: ...
 */
public enum Configuration {
	C1_1,
	C1_2,
	C2_1,
	C2_2
}
